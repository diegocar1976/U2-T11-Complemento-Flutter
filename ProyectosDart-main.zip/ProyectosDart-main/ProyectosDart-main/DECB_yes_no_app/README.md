# cegd_yes_no_app

A new Flutter project.

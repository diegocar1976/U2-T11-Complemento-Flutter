class Config {
  static const String apiUrl = 'https://api.example.com';
  // Otros parámetros de configuración
}